# KPI de nível terciário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Níveis de KPI (Ni%CC%81veis%20de%20KPI%207002a5079f654b2a9192286d6091321b.md)

## Descrição

-