# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Custo Médio (Custo%20Me%CC%81dio%208118bb13a29749deadfe51391089d4db.md)

## Descrição

-