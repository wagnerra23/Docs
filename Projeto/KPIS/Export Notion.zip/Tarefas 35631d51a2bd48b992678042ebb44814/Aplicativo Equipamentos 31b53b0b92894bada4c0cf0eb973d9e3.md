# Aplicativo Equipamentos

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Taxa de Equipamentos Sem Rateio (Taxa%20de%20Equipamentos%20Sem%20Rateio%20144243c9429f4b338341402b6f2b6b23.md), Taxa de Equipamentos Sem Mensalidade (Taxa%20de%20Equipamentos%20Sem%20Mensalidade%20fb1e194251104bf0930f449727d7c2b2.md), Taxa de Equipamentos sem Rateio Antifurto (Taxa%20de%20Equipamentos%20sem%20Rateio%20Antifurto%200ef08def455c43e685c8859c43eb8a08.md), Taxa de Equipamentos com Boleto Gerado (Taxa%20de%20Equipamentos%20com%20Boleto%20Gerado%20fbf5cb3fde4944c3a8d965641b014ea3.md), Tempo Médio Entre Ocorrências (Tempo%20Me%CC%81dio%20Entre%20Ocorre%CC%82ncias%20dd7549b813e042298da242902342b340.md), Taxa de Equipamentos sem Contribuição (Taxa%20de%20Equipamentos%20sem%20Contribuic%CC%A7a%CC%83o%206f1b7f7d7651481c806c5c399eea5015.md), Taxa de Caminhões (Taxa%20de%20Caminho%CC%83es%20d0550bb183fb4d8aad0d4fbb2b2e119e.md), Taxa de Semi-Reboques (Taxa%20de%20Semi-Reboques%20bee8987b0b5b4002a917a00886d0c60a.md), Taxa de Veículos sem Atualização Pela Tabela Fipe (Taxa%20de%20Vei%CC%81culos%20sem%20Atualizac%CC%A7a%CC%83o%20Pela%20Tabela%20Fi%20d186953c3f2e4407bf79291481fffbec.md), Base Média para Rateio no Período (Base%20Me%CC%81dia%20para%20Rateio%20no%20Peri%CC%81odo%2060a5c31988b448f48aa6ffe713737e76.md)
Tarefa principal: Módulo Associação (Mo%CC%81dulo%20Associac%CC%A7a%CC%83o%207e02fd8f26b241c9b8b5f4fd5ab4988c.md)
Tags: Saldo

## Descrição

-