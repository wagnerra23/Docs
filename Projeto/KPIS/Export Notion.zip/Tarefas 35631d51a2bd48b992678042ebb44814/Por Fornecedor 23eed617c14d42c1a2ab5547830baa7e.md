# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Produtos Acima do Estoque Máximo (Taxa%20de%20Produtos%20Acima%20do%20Estoque%20Ma%CC%81ximo%20d00c6443f89e4156a40a17714688924b.md)

## Descrição

-