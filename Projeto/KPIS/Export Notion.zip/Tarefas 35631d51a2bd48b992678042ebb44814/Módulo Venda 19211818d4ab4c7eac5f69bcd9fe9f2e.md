# Módulo Venda

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Aplicativo PAF (Aplicativo%20PAF%2074ff8198c4f145b889b8b6686f5d6b1c.md), Aplicativo PDV (Aplicativo%20PDV%20792fd851079c41edbfb330dc56f2b908.md), Aplicativo Comissão de Venda (Aplicativo%20Comissa%CC%83o%20de%20Venda%207a5999d81a754a45bb1a946c153b5cd4.md), Aplicativo Crédito de Cliente (Aplicativo%20Cre%CC%81dito%20de%20Cliente%207f2ceec7a40740a2bc8a732de69e2036.md), Aplicativo Markup (Aplicativo%20Markup%20d24540291e3444bd8674cd1b9d0f6458.md), Aplicativo Pedido de Venda (Aplicativo%20Pedido%20de%20Venda%20170372c1ba694d10a8ab436831748135.md), Aplicativo Mecânica (Aplicativo%20Meca%CC%82nica%20c241fa04de0a4f99be5e43b571637ef5.md), Aplicativo Tabela de Preço (Aplicativo%20Tabela%20de%20Prec%CC%A7o%20d4498b437a2042359886aa8679029e15.md), Aplicativo Venda (Aplicativo%20Venda%207b7bf41d76694ed79bfc4346c2614df1.md), Aplicativo TEF (Aplicativo%20TEF%205b7d09e3276349eb9ddbeb32023d94af.md), Aplicativo Metas de Venda (Aplicativo%20Metas%20de%20Venda%2023f58bd18dff4865b753883408a148ba.md), Aplicativo Devolução (Aplicativo%20Devoluc%CC%A7a%CC%83o%20af999742459b443c8503e74ed059708c.md)
Tarefa principal: EMPRESA (EMPRESA%201a28ba15cf0742499f888af9f25353c5.md)
Tags: = Saldo Atual, Despesa, Receita

## Descrição

-