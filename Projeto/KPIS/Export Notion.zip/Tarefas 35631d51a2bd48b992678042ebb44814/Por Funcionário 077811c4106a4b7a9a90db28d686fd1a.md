# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas sem Faturamento NFC-e (Taxa%20de%20Notas%20sem%20Faturamento%20NFC-e%202807d5e041b9482fa40c5f449378c012.md)

## Descrição

-