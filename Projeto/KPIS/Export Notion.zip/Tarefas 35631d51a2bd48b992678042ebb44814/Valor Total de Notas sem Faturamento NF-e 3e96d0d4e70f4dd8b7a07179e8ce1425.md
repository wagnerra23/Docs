# Valor Total de Notas sem Faturamento NF-e

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Aplicativo NF-e (Aplicativo%20NF-e%206408f7e696e44074a7f68d6002bc3c72.md)
Tags: BI, Revisar

> **Prós:**
> 

> **Contras:**
> 

> **Módulo Responsável:**
> 

> **Função Principal:**
> 

> **Quais Configurações deve ter?**
> 

> **Formato de Exibição?**
> 

> **Possuí Relatórios? Quais?**
> 

> **Requisitos para utilizar? E quais métricas se associam a esse KPI?**
>