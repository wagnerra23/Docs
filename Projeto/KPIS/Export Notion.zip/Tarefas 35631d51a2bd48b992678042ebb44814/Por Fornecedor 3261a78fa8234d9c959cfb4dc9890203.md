# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Nível de Estoque Máximo (Ni%CC%81vel%20de%20Estoque%20Ma%CC%81ximo%20476be4cc069e4b65b76ea5bf544c2988.md)

## Descrição

-