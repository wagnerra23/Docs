# Taxa de Ocorrências com Monta Pequena

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%2073a4e47a52dc4cccae4c73e32d0df916.md), Por Placa (Por%20Placa%20dfa1561fa8ee45809b9c7e7fce8557e0.md)
Tarefa principal: Aplicativo Ocorrências (Aplicativo%20Ocorre%CC%82ncias%20657c527575164ad8b8f69dbcc9c7b81e.md)

## Descrição

-