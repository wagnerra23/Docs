# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio de Rotação (Tempo%20Me%CC%81dio%20de%20Rotac%CC%A7a%CC%83o%204e46e76a0bc34a219ae8bc910820031a.md)

## Descrição

-