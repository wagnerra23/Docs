# Por Placa

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Ocorrências com danos Totais (Taxa%20de%20Ocorre%CC%82ncias%20com%20danos%20Totais%20bc1203687c7e4113b56c1940e062ea72.md)

## Descrição

-