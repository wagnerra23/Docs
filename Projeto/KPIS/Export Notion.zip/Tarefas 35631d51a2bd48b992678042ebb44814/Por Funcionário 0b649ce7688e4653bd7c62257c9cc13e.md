# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio para Alcance da Meta (Tempo%20Me%CC%81dio%20para%20Alcance%20da%20Meta%20a16b83aa37a84d75af8613e4e4508db0.md)

## Descrição

-