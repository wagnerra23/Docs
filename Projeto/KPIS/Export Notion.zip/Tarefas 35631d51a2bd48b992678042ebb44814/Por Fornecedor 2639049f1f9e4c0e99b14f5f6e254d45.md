# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Total do Estoque Balanço de Estoque (Valor%20Total%20do%20Estoque%20Balanc%CC%A7o%20de%20Estoque%2034f3b86dedf24150ae1b8383dfe3cfe2.md)

## Descrição

-