# Não faturadas

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Cliente (Por%20Cliente%201078e1dd8eff491c8a22cdf2a47533eb.md), Por Funcionário (Por%20Funciona%CC%81rio%201e4e3bd71e8f421194466c5da322e581.md), Por Tipo de Venda (Por%20Tipo%20de%20Venda%20589703611014475494a11861484ebc0f.md)
Tarefa principal: Aplicativo Venda (Aplicativo%20Venda%207b7bf41d76694ed79bfc4346c2614df1.md)
Descrição: Valor total de vendas ativas que não foram faturadas.

> **Prós:**
> 
> 
> Oferece insights sobre a eficiência do processo de vendas e faturamento.
> 
> Ajuda a identificar possíveis gargalos ou ineficiências que impedem o faturamento.
> 
> Pode indicar problemas na gestão de pedidos ou na comunicação entre os departamentos de vendas e financeiro.
> 

> **Contras:**
> 
> 
> Se usado isoladamente, pode não fornecer informações sobre as causas subjacentes dos atrasos no faturamento.
> 
> A interpretação pode ser complexa, especialmente se o número de vendas não faturadas variar devido a fatores sazonais ou específicos do mercado.
> 

> **Módulo Responsável:**
Venda
> 

> **Função Principal:**
Medir o valor total das vendas que foram realizadas, mas que ainda não foram faturadas. Isso ajuda a entender a eficácia e a rapidez do processo de faturamento.
> 

> **Quais Configurações deve ter?**
> 
> 
> Filtros por período, tipo de produto, cliente ou região.
> 
> Capacidade de identificar razões para a falta de faturamento (por exemplo, atrasos na entrega, problemas de processamento de pedidos).
> 
> Opções para comparar com períodos anteriores ou metas estabelecidas.
> 

> **Formato de Exibição?**
> 
> 
> Exibição como um valor monetário total.
> 
> Gráficos de barras ou linhas para mostrar tendências ao longo do tempo.
> 
> Inclusão em relatórios de análise de desempenho de vendas e faturamento.
> 

> **Possuí Relatórios? Quais?**
Sim. Relatórios de vendas pendentes de faturamento, análises de eficiência do processo de faturamento, e relatórios de acompanhamento do ciclo de vendas.
> 

> **Requisitos para utilizar? E quais métricas se associam a esse KPI?**
> 
> 
> Sistema integrado de gestão de vendas e faturamento que possa rastrear e reportar o status do faturamento das vendas.
> 
> **Métricas associadas:** 
> Tempo médio para faturamento, percentual de vendas faturadas dentro do período, e eficácia do processo de faturamento.
> 

<aside>
💡 **Programação:**

</aside>