# Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Aprovadas (Aprovadas%20fbdcd6e0e59b43c3a81fab18aa096e32.md)

## Descrição

-