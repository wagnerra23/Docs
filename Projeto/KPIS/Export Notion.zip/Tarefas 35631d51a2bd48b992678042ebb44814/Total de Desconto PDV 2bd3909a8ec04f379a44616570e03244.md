# Total de Desconto PDV

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Funcionário (Por%20Funciona%CC%81rio%207234d9f7a63643ad88e3564b2e7398f1.md), Por Cliente (Por%20Cliente%2067bba45859b34b708ddbc32eddb56499.md), Por Produto (Por%20Produto%203ffae066dd3545a687474bedb37df95f.md), Por Categoria (Por%20Categoria%201974d379dd2d4501b68fa85641d9da05.md), Por Grupo (Por%20Grupo%20a09ab7b0f53f4ad88c3a885ff0fcab52.md), Por Condição de Pagamento (Por%20Condic%CC%A7a%CC%83o%20de%20Pagamento%20cd8385f35d4343419bc03ef62389040e.md)
Tarefa principal: Aplicativo PDV (Aplicativo%20PDV%20792fd851079c41edbfb330dc56f2b908.md)
Descrição: Valor total dos descontos concedidos nas vendas realizadas.

> **Prós:**
> 
> 
> **Atratividade de Vendas:** Oferecer descontos pode aumentar a atratividade das vendas, incentivando mais compras e atraindo novos clientes.
> 
> **Estratégia de Preços Flexível:** O acompanhamento dos descontos permite avaliar a eficácia das estratégias de precificação e promoções.
> 

> **Contras:**
> 
> 
> **Impacto na Margem de Lucro:** Descontos excessivos podem reduzir a margem de lucro das vendas.
> 
> **Hábito de Espera por Descontos:** Clientes podem se acostumar com os descontos e diminuir as compras a preço integral, esperando por promoções.
> 

> **Módulo Responsável:**
Venda
> 

> **Função Principal:**
Medir o valor total dos descontos concedidos nas vendas realizadas no PDV.
> 

> **Quais Configurações deve ter?**
> 
> 
> **Definição de Desconto:** Especificar quais tipos de descontos são incluídos no cálculo (por exemplo, descontos promocionais, descontos por volume).
> 
> **Período de Avaliação:** Determinar a frequência com que o KPI será avaliado (diariamente, semanalmente, mensalmente).
> 

> **Formato de Exibição?**
> 
> 
> **Gráficos e Tabelas:** Utilizar gráficos para mostrar a tendência dos descontos ao longo do tempo e tabelas para detalhes.
> 
> **Dashboards Interativos:** Painéis que exibem informações detalhadas sobre os descontos aplicados nas vendas.
> 

> **Possuí Relatórios? Quais?**
> 
> 
> **Análise Detalhada dos Descontos:** Relatórios que incluem detalhes sobre os descontos, como tipos de desconto mais comuns, períodos de maior aplicação e categorias de produtos mais afetadas.
> 
> **Impacto dos Descontos no Desempenho de Vendas:** Avaliar como os descontos afetam o volume total de vendas e a rentabilidade.
> 

> **Requisitos para utilizar? E quais métricas se associam a esse KPI?**
> 
> 
> **Sistema de PDV Eficiente:** Um sistema que registre as vendas e os descontos aplicados de forma precisa.
> **Competência em Análise de Dados de Vendas:** Habilidade para analisar os dados de vendas e avaliar o impacto das estratégias de desconto.
> 
> **Métricas Associadas:**
> 
> - **Percentual de Desconto sobre Vendas Totais:** Medir os descontos como uma porcentagem das vendas totais.
> - **Efetividade dos Descontos na Atração de Clientes:** Avaliar se os descontos estão efetivamente atraindo mais clientes ou aumentando o volume de vendas.

## Programação

- [ ]  Indicador dentro do **Saldo de Vendas** da **Tela de KPI’s.**
- [ ]  ALTER TABLE **VENDA** ADD **TEM_TABELA_PRECO** VARCHAR(1);
- [ ]  **Criar campos no Banco de Dados. (UPDATE SQL)**
    - [ ]  ALTER TABLE **VENDA** ADD **TEM_DESCONTO** VARCHAR(1);
    - [ ]  ALTER TABLE **VENDA** ADD **TEM_DESCONTO_PRODUTO_MANUAL** VARCHAR(1);
    - [ ]  ALTER TABLE **VENDA** ADD **CODRESPONSAVEL_DESCONTO** VARCHAR(15);
    - [ ]  ALTER TABLE **VENDA** ADD **CODRESPONSAVEL_DESCONTO_TABELA** VARCHAR(15);
    - [ ]  ALTER TABLE **VENDA** ADD **CODRESPONSAVEL_DESCONTO_PRODUTO_MANUAL** VARCHAR(15);
    - [ ]  ALTER TABLE **VENDA** ADD **CODUSUARIO_DESCONTO** VARCHAR(15);
    - [ ]  ALTER TABLE **VENDA** ADD **CODUSUARIO_DESCONTO_TABELA** VARCHAR(15);
    - [ ]  ALTER TABLE **VENDA** ADD **CODUSUARIO_DESCONTO_PRODUTO_MANUAL** VARCHAR(15);
    - [ ]  ALTER TABLE **VENDA** ADD **VDESC_TABELA_PRECO** DOUBLE PRECISION;
    - [ ]  ALTER TABLE **VENDA** ADD **VDESC_PRODUTO_MANUAL** DOUBLE PRECISION;
- [ ]  **Filtros para o KPI.**
    - Período
    - Faturadas.
    - Não Faturadas.
    - Todas as Vendas (Faturas e não faturadas).
        - Sub por funcionário.
            - Campo “DESCONTO”
            - Alteração Manual do Valor do Produto.
        - Sub por Categoria.
        - Sub por Grupo.
        - Sub por Tabela de Preço.
- [ ]  **Desconto Funcionário.**
    - **Origem:**
        - Campo “DESCONTO” tabela VENDA.
        - Alteração manual do valor do produto.
    - [ ]  No **EXIT** do campo de **VALOR** verifica se o **VALOR <> CALC_VALOR_ORIGINAL and VDESC = 0.**
        - Preencher o campo **TEM_DESCONTO_PRODUTO_MANUAL = ‘S’.**
        - Preencher o campo **VDESC_PRODUTO_MANUAL = CALC_VALOR_ORIGINAL - VALOR**
        - Preencher o campo **CODUSUARIO_DESCONTO_PRODUTO_MANUAL  = CODIGO DO USUARIO QUE ESTA EDITANDO A VENDA.**
        - Verifica se “Solicitar senha de responsável para alterar valor do produto na venda.” está ativa.
            - Abre um **COMBO** que irá exibir o nome do funcionário vinculado ao usuário e um campo para colocar a senha.
            - **CODRESPONSAVEL_DESCONTO_PRODUTO_MANUAL = CODIGO DO USUARIO DO COMBO.**
    - [ ]  **Controles:**
        - [ ]  **Permissão:** Bloquear campo de desconto para o usuário.
            - Deixa o campo desconto **ENABLE**.
            - Verifica as permissões de usuário na abertura da tela.
        - [ ]  **Configuração:** Limitar a porcentagem de desconto para vendas.
            - Campo para preencher a porcentagem limite.
        - [ ]  **Configuração:** Solicitar senha de responsável ao dar Desconto.
            - Grid para adicionar quem pode liberar desconto com senha.
            - Solicitar senha sempre.
            - Solicitar senha somente quando ultrapassar o limite.
            - Desbloquear campo de desconto.
                - Bloqueia novamente o campo no **EXIT**.
            - Sempre registra o responsável que permitiu o desconto.
        - [ ]  **Configuração:** Bloquear alteração manual o valor do produto na venda.
            - Impede que o valor do produto seja alterado quando estiver adicionando o mesmo a venda.
            - Impede que o valor do produto seja alterado no grid.
        - [ ]  **Configuração:** Solicitar senha de responsável para alterar valor do produto na venda.
            - Grid para adicionar responsáveis que poderão liberar alteração do valor.
            - Solicitar senha sempre.
            - Solicitar senha somente quando configuração “Bloquear alteração manual o valor do produto na venda” estiver ativa.
                - Bloquear novamente no **EXIT** do campo.
        - [ ]  **EXIT** do campo **DESCONTO. Verifica:**
            - Verifica se “Limitar a porcentagem de desconto para vendas.” está **ativa**.
                - Verifica se o percentual não ultrapassa o limite configurado.
            - Verifica se “Solicitar senha de responsável ao dar Desconto” está **ativa**.
                - Abre um **COMBO** que irá exibir o nome do funcionário vinculado ao usuário e um campo para colocar a senha.
                - **CODRESPONSAVEL_DESCONTO = CODIGO DO USUARIO DO COMBO.**
            - Registra usuário responsável pela venda. (Sempre)
            - Registra usuário responsável por liberar desconto. (Quando a configuração “Solicitar senha de responsável ao dar Desconto” estiver ativa)
            - Se o campo **DESCONTO > 0** então o campo **TEM_DESCONTO = ‘S’** e o campo **CODUSUARIO_DESCONTO = CODIGO DO USUARIO QUE ESTA EDITANDO A VENDA.**
- [ ]  **Tabela de Preço**
    - [ ]  Se o produto sofrer alteração no valor por tabela de preço preencher o valor do desconto no campo **VDESC_TABELA_PRECO** da tabela **VENDA.**
    - [ ]  Se o campo **VDESC_TABELA_PRECO > 0** então o campo **TEM_DESCONTO_TABELA = ‘S’**
    - [ ]  Ao preencher o código da tabela de preço verifica se o controle “Solicitar senha para usar Tabela de Preço.” está ativa.
        - Abre um **COMBO** que irá exibir o nome do funcionário vinculado ao usuário e um campo para colocar a senha.
            - **CODRESPONSAVEL_DESCONTO_TABELA = CODIGO DO USUARIO DO COMBO.**
    - **Controles:**
        - [ ]  **Configuração:** Limitar desconto por Tabela de Preço.
            - Campo para configurar o percentual de desconto limite.
        - [ ]  **Configuração:** Bloquear Tabela de Preço.
            - Bloqueia desconto por Tabela de Preço.
        - [ ]  **Configuração:** Solicitar senha para usar Tabela de Preço.
            - Grid para adicionar quem pode liberar desconto com senha.
            - Solicitar senha sempre.
            - Solicitar senha somente quando a configuração “Bloquear Tabela de Preço.” estiver ativa .
            - Sempre registra o responsável que permitiu o uso da Tabela de Preço.