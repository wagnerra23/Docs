# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Itens Cancelados (Itens%20Cancelados%20af442d98a3454b7a866b454107885d89.md)

## Descrição

-