# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Nível de Serviço de Estoque (Ni%CC%81vel%20de%20Servic%CC%A7o%20de%20Estoque%202708e016321547d7968302ee5b5a526b.md)

## Descrição

-