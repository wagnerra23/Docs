# Por Associado

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Boletos Contestados (Taxa%20de%20Boletos%20Contestados%20d62b034dd9104d2b97bb15bfa567d617.md)

## Descrição

-