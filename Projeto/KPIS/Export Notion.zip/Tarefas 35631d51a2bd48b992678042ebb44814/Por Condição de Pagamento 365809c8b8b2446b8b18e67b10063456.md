# Por Condição de Pagamento

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Médio de Transação (Valor%20Me%CC%81dio%20de%20Transac%CC%A7a%CC%83o%20999b7493bcca4e8f82aeb85fcd09093f.md)

## Descrição

-