# Por Categoria

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Acréscimo PDV (Total%20de%20Acre%CC%81scimo%20PDV%2060d29d0b8fa945209d0ce7c8cec09726.md)

## Descrição

-