# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Rendimento (Taxa%20de%20Rendimento%207f60c503f72b4afc8908b5440fcd7409.md)

## Descrição

-