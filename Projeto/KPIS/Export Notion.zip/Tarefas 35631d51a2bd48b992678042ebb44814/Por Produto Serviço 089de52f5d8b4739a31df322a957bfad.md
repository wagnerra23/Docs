# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Ciclo Médio de Compra (Ciclo%20Me%CC%81dio%20de%20Compra%204ee56c0b905947f39ee254887f103ad9.md)

## Descrição

-