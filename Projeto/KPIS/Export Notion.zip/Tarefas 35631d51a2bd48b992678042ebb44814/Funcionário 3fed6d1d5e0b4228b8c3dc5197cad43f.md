# Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Média de Lucro Proposta (Me%CC%81dia%20de%20Lucro%20Proposta%205bad1d7bbea44e7b9e0977bac2085354.md)

## Descrição

-