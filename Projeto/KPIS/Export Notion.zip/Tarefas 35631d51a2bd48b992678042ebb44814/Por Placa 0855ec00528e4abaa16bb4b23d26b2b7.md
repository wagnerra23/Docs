# Por Placa

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Cancelamento de Boletos (Taxa%20de%20Cancelamento%20de%20Boletos%2069dbcb0951cb4711afa214a3635ebf76.md)

## Descrição

-