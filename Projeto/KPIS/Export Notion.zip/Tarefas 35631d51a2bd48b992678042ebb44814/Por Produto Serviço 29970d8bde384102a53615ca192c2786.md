# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Abaixo do Mínimo (Abaixo%20do%20Mi%CC%81nimo%204861b963004f40348b0c481e636d080c.md)

## Descrição

-