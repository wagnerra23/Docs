# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Total dos Impostos Declarados NF-e (Valor%20Total%20dos%20Impostos%20Declarados%20NF-e%2070142557a136468c82c2afb0730a1a09.md)

## Descrição

-