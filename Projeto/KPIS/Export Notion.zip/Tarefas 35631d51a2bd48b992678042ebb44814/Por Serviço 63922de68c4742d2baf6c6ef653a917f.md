# Por Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Serviços fora do Prazo (Servic%CC%A7os%20fora%20do%20Prazo%20a764be5d93d6430cad8c7b762c999bb9.md)

## Descrição

-