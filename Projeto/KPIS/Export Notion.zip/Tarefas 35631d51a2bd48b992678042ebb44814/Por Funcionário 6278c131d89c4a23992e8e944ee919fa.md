# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Pedidos Recorrentes (Pedidos%20Recorrentes%2080158ab788a14c6f8935f2e0fb000828.md)

## Descrição

-