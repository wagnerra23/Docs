# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Prazo Médio de Recebimento (Prazo%20Me%CC%81dio%20de%20Recebimento%2009dd3234e14f4243bf17050bbd1e791f.md)

## Descrição

-