# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Volume de Pedidos (Volume%20de%20Pedidos%203b9c4820d926442784b109c42837b644.md)

## Descrição

-