# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Pagamentos Realizados (Pagamentos%20Realizados%2079b6f6d01a08454e90ad68df4fb75d96.md)

## Descrição

-