# Base Média para Rateio no Período

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Aplicativo Equipamentos (Aplicativo%20Equipamentos%2031b53b0b92894bada4c0cf0eb973d9e3.md)

## Descrição

-