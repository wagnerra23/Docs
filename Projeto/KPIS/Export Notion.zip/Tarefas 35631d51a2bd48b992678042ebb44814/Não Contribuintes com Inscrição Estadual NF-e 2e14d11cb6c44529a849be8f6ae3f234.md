# Não Contribuintes com Inscrição Estadual NF-e

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Cliente (Cliente%20b836b0e08d7d4361a782b4ebd2fb3dc8.md), Fornecedor (Fornecedor%206b305353dd2a4c26a77d90c91b843ee6.md)
Tarefa principal: Aplicativo NF-e (Aplicativo%20NF-e%206408f7e696e44074a7f68d6002bc3c72.md)
Descrição: Número de cadastros classificados como Não Contribuintes que erroneamente possuem Inscrição Estadual.

> **Prós:**
> 
> 
> **Conformidade Fiscal:** Ajuda a identificar e corrigir discrepâncias nos registros fiscais, garantindo conformidade com as regulamentações tributárias.
> 
> **Precisão na Documentação Fiscal:** Contribui para a precisão na emissão de documentos fiscais, refletindo corretamente o status fiscal de cada cliente ou fornecedor.
> 
> **Gestão de Risco:** Reduz o risco de penalidades ou ajustes fiscais decorrentes de informações cadastrais incorretas.
> 

> **Contras:**
> 
> 
> **Complexidade na Gestão de Cadastros:** Pode ser desafiador verificar e manter a precisão em uma grande quantidade de dados cadastrais.
> 
> **Necessidade de Revisão Contínua:** Exige esforços constantes para revisar e atualizar os cadastros para assegurar a conformidade.
> 

> **Módulo Responsável:**
Fiscal
> 

> **Função Principal:**
Monitorar a quantidade de cadastros de clientes ou fornecedores classificados como não contribuintes que, erroneamente, possuem uma Inscrição Estadual registrada, visando corrigir tais inconsistências para garantir a correta classificação fiscal.
> 

> **Quais Configurações deve ter?**
> 
> 
> Definição do período de análise (diário, semanal, mensal, anual).
> 
> Segmentação por tipo de cliente ou fornecedor, setor de mercado ou localização geográfica.
> 
> Capacidade de identificar e acompanhar a correção desses registros.
> 

> **Formato de Exibição?**
Gráficos de barras ou linhas para visualizar tendências e valores numéricos para apresentar a contagem atual de casos.
> 

> **Possuí Relatórios? Quais?**
> 
> 
> Sim, pode incluir relatórios como:
> 
> Detalhamento dos cadastros de não contribuintes com inscrição estadual.
> 
> Análise de tendências e comparação com períodos anteriores.
> 
> Relatórios de auditoria para verificar a conformidade dos registros.
> 

> **Requisitos para utilizar? E quais métricas se associam a esse KPI?**
> 
> 
> Sistema de gestão de clientes ou fornecedores que permita o registro detalhado das informações fiscais, incluindo a Inscrição Estadual.
> 
> **Métricas Associadas:**
> Percentual de Cadastros Não Contribuintes com Inscrição Estadual em Relação ao Total de Não Contribuintes, Tempo Médio para Correção de Cadastros, Impacto nos Processos de Vendas e Fiscalização.
> 

<aside>
💡 **Programação**:

</aside>