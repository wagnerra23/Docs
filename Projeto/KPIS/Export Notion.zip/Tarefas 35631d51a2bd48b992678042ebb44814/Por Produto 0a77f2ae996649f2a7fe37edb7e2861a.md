# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Margem de Lucro Fabricação (Margem%20de%20Lucro%20Fabricac%CC%A7a%CC%83o%20833455d145894dc183ac9bf6ad56babe.md)

## Descrição

-