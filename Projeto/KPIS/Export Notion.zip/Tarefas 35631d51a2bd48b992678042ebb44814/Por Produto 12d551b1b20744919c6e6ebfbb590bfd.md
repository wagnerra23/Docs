# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Lotes com Alterações (Taxa%20de%20Lotes%20com%20Alterac%CC%A7o%CC%83es%20bfebdc0c54c04660807d73b106674362.md)

## Descrição

-