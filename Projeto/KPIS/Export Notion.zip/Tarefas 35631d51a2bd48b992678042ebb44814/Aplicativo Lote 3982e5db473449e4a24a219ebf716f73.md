# Aplicativo Lote

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Valor Total de Produtos Expirados (Valor%20Total%20de%20Produtos%20Expirados%209772f9e46b9d4579a77d43efdd740279.md), Tempo Médio de Rotação (Tempo%20Me%CC%81dio%20de%20Rotac%CC%A7a%CC%83o%204e46e76a0bc34a219ae8bc910820031a.md), Taxa de Utilização de Capacidade (Taxa%20de%20Utilizac%CC%A7a%CC%83o%20de%20Capacidade%2013fd81c18ec74cb5b399e2babb4e82c2.md), Tempo Médio de Vida Útil Restante (Tempo%20Me%CC%81dio%20de%20Vida%20U%CC%81til%20Restante%2023d02b0d9a444200b888f891c1fcf23e.md), Eficiência de Rotação de Estoque (Eficie%CC%82ncia%20de%20Rotac%CC%A7a%CC%83o%20de%20Estoque%20f96cc45f58af4dda86c31d44ab7cde86.md), Taxa de Lotes com Alterações (Taxa%20de%20Lotes%20com%20Alterac%CC%A7o%CC%83es%20bfebdc0c54c04660807d73b106674362.md), Valor Total de Desconto  (Valor%20Total%20de%20Desconto%20d38fdf11d7d04700884d4dcf31a1460b.md), Valor Total de Acréscimo Lote (Valor%20Total%20de%20Acre%CC%81scimo%20Lote%200be3c39e443d4cb1bc365c9ad5a17024.md), Taxa de Rastreabilidade (Taxa%20de%20Rastreabilidade%20cec5f8a74cb443149804025f392b5935.md), Valor Total Lote (Valor%20Total%20Lote%203a0651271d4c4fe2a4745a391585d5cd.md)
Tarefa principal: Módulo Estoque (Mo%CC%81dulo%20Estoque%2057c521e5356048fd955bdddfeedec937.md)

## Descrição

-