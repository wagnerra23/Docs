# Por Associado

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Equipamentos sem Rateio Antifurto (Taxa%20de%20Equipamentos%20sem%20Rateio%20Antifurto%200ef08def455c43e685c8859c43eb8a08.md)

## Descrição

-