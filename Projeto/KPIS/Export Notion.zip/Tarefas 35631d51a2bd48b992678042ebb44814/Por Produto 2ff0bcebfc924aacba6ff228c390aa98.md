# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Total de Acréscimo Lote (Valor%20Total%20de%20Acre%CC%81scimo%20Lote%200be3c39e443d4cb1bc365c9ad5a17024.md)

## Descrição

-