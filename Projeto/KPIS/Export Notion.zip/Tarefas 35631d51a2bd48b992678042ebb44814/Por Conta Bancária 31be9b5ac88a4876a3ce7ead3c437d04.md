# Por Conta Bancária

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Juros Pagos (Total%20de%20Juros%20Pagos%20e97ad8586f7f44f3af1174c6c50c8869.md)

## Descrição

-