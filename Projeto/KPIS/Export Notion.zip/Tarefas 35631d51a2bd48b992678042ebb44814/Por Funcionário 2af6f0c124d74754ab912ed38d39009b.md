# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas Não Autorizadas (Taxa%20de%20Notas%20Na%CC%83o%20Autorizadas%20ab650a3fbc4c4f52ac51e628e1c99f00.md)

## Descrição

-