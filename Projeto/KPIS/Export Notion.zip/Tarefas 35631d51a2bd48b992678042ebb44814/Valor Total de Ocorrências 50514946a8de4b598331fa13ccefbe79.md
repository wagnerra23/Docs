# Valor Total de Ocorrências

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%200fc60032384a43d0ba0fc6fc20599022.md), Por Placa (Por%20Placa%206e0e786d39ed427aa58c86a029015b3e.md)
Tarefa principal: Aplicativo Ocorrências (Aplicativo%20Ocorre%CC%82ncias%20657c527575164ad8b8f69dbcc9c7b81e.md)

## Descrição

-