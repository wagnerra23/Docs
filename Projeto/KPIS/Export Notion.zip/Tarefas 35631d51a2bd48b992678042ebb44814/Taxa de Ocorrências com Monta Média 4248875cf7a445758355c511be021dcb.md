# Taxa de Ocorrências com Monta Média

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%2016fac925b0e14c02a3fb3ef1fce6d84c.md), Por Placa (Por%20Placa%20f6d1083968b0478588117f566a893ac9.md)
Tarefa principal: Aplicativo Ocorrências (Aplicativo%20Ocorre%CC%82ncias%20657c527575164ad8b8f69dbcc9c7b81e.md)

## Descrição

-