# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas sem Faturamento NF-e (Taxa%20de%20Notas%20sem%20Faturamento%20NF-e%2038946781ca2046dc9df855ca5ce06808.md)

## Descrição

-