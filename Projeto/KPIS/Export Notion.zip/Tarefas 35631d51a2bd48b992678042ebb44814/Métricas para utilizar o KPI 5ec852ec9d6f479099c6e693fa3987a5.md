# Métricas para utilizar o KPI?

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Retorno de Produtos Defeituosos (Taxa%20de%20Retorno%20de%20Produtos%20Defeituosos%20ea0c4c23b69d4447848dddbba4f1ac3b.md)

## Descrição

-