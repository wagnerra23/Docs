# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas com Acréscimo NF-e (Taxa%20de%20Notas%20com%20Acre%CC%81scimo%20NF-e%20b5d7f5278c2b402598a0d3984a79930b.md)

## Descrição

-