# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Receita Média  (Receita%20Me%CC%81dia%20a94c8991ab464a698134d48e849002ee.md)

## Descrição

-