# Telefone Não Informado ou Incompleto NF-e

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Cliente (Cliente%20edbcfe2e0cb448558be6b5e856d4b9ff.md), Fornecedor (Fornecedor%200f530119b513457aaf07ec4571a47d4a.md)
Tarefa principal: Aplicativo NF-e (Aplicativo%20NF-e%206408f7e696e44074a7f68d6002bc3c72.md)
Descrição: Número de cadastros onde o telefone não foi informado ou está incompleto.

> **Prós:**
> 
> 
> **Melhoria na Comunicação:** Facilita a comunicação eficiente com clientes ou fornecedores, importante para esclarecimentos, suporte ou acompanhamento de pedidos.
> 
> **Eficiência no Processo de Faturamento:** Ajuda a garantir a emissão de notas fiscais sem atrasos decorrentes da falta de informações de contato.
> 
> **Qualidade no Atendimento ao Cliente:** Contribui para um melhor atendimento e satisfação do cliente, permitindo uma comunicação rápida e direta quando necessário.
> 

> **Contras:**
> 
> 
> **Desafio na Manutenção de Dados:** Manter as informações de contato atualizadas pode ser complexo, especialmente em empresas com um grande número de clientes ou fornecedores.
> 
> **Necessidade de Verificação Regular:** Requer esforços constantes para verificar e atualizar as informações de contato nos cadastros.
> 

> **Módulo Responsável:**
Fiscal
> 

> **Função Principal:**
Monitorar o número de cadastros de clientes ou fornecedores que estão com o número de telefone incompleto ou não informado, afetando a capacidade de comunicação eficaz e a emissão correta de notas fiscais.
> 

> **Quais Configurações deve ter?**
> 
> 
> Definição do período de análise (diário, semanal, mensal, anual).
> 
> Segmentação por tipo de cliente ou fornecedor, setor de mercado ou localização geográfica.
> 
> Capacidade de identificar e acompanhar a atualização desses registros.
> 

> **Formato de Exibição?**
Gráficos de barras ou linhas para visualizar tendências e valores numéricos para apresentar a contagem atual de casos.
> 

> **Possuí Relatórios? Quais?**
> 
> 
> Sim, pode incluir relatórios como:
> 
> Detalhamento dos cadastros com telefone incompleto ou não informado.
> 
> Análise de tendências e comparação com períodos anteriores.
> 
> Relatórios de acompanhamento para monitorar a atualização dos registros de contato.
> 

> **Requisitos para utilizar? E quais métricas se associam a esse KPI?**
Sistema de gestão de clientes ou fornecedores que permita o registro detalhado das informações de contato, incluindo números de telefone.
> 
> 
> **Métricas Associadas:** 
> Percentual de Cadastros com Telefone Incompleto ou Não Informado em Relação ao Total de Cadastros, Tempo Médio para Completar ou Corrigir Cadastros, Impacto na Eficácia da Comunicação e nos Processos de Faturamento.
> 

<aside>
💡 **Programação:**

</aside>