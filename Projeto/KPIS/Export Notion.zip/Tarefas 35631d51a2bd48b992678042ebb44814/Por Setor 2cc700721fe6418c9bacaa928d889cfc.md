# Por Setor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Total de Folhas (Valor%20Total%20de%20Folhas%2015e26c8ad8a149b9a56ff72a1b531711.md)

## Descrição

-