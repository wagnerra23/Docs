# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Custo Total de Comissões como Percentual das Vendas (Custo%20Total%20de%20Comisso%CC%83es%20como%20Percentual%20das%20Vend%20a481a8f2eacc4a028c17c3197351e6ed.md)

## Descrição

-