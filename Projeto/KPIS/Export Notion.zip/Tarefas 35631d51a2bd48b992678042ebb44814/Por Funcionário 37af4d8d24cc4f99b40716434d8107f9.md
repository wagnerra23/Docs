# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Acréscimo Mecânica (Total%20de%20Acre%CC%81scimo%20Meca%CC%82nica%20455c943bf5c74991857169920769c191.md)

## Descrição

-