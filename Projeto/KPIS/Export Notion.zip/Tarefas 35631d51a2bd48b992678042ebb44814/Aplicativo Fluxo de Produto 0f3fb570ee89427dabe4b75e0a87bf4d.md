# Aplicativo Fluxo de Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Taxa de Alteração da Equipe Padrão (Taxa%20de%20Alterac%CC%A7a%CC%83o%20da%20Equipe%20Padra%CC%83o%2052e9c82009d84e7e84e5dced3506e0b8.md), Taxa de Pré-Requisitos (Taxa%20de%20Pre%CC%81-Requisitos%20f1e46a48810e42e095d36c5b7d44fd3c.md), Baixa Automática Ativa (Baixa%20Automa%CC%81tica%20Ativa%202a5c2e0fd193472493605875d0739b36.md), Média de Etapas (Me%CC%81dia%20de%20Etapas%201945765e05174cba95aa70fd467fd35e.md), Média de Tempo de Espera (Me%CC%81dia%20de%20Tempo%20de%20Espera%20a2e6263236334bc0a8334457a4e7990e.md)
Tarefa principal: Módulo Produção (Mo%CC%81dulo%20Produc%CC%A7a%CC%83o%209c742a8e253f45c0baa028ea30ec8d74.md)

## Descrição

-