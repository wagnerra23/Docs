# Por Condição de Pagamento

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor de Juros Pagos (Valor%20de%20Juros%20Pagos%20c2ec26d5b02c4215a7969978122b1312.md)

## Descrição

-