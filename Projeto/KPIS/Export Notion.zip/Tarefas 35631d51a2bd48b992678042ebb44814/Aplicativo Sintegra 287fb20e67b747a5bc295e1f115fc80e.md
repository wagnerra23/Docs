# Aplicativo Sintegra

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Módulo Contábil (Mo%CC%81dulo%20Conta%CC%81bil%205a1670466a984420895aef7a34b0b0d9.md)

## Descrição

-