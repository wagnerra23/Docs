# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio de Processamento de Pedido (Tempo%20Me%CC%81dio%20de%20Processamento%20de%20Pedido%206af3f81968db4980a354ca5f041f8f6f.md)

## Descrição

-