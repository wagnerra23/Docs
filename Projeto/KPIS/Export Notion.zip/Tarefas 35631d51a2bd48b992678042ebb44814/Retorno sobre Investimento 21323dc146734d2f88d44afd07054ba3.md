# Retorno sobre Investimento

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%2021adc2feed6d48f38545548eb80c0f8b.md), Por Placa (Por%20Placa%20759a7c7f04f441b790a96a8cff53d566.md)
Tarefa principal: Aplicativo Rateio (Aplicativo%20Rateio%2043ef72bc1ec7467bbd761e2d5fc3ca98.md)

## Descrição

-