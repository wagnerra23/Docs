# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Total de INSS (Valor%20Total%20de%20INSS%20b2e346bd360d4139967994de38afee7b.md)

## Descrição

-