# Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Conversões Automáticas vs. Manuais (Taxa%20de%20Converso%CC%83es%20Automa%CC%81ticas%20vs%20Manuais%20d6e088d73855487ea82b06271d8096ac.md)

## Descrição

-