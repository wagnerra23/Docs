# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas Fiscais Desconhecidas NFC-e (Taxa%20de%20Notas%20Fiscais%20Desconhecidas%20NFC-e%208197c948e9824278bf7896827a34612b.md)

## Descrição

-