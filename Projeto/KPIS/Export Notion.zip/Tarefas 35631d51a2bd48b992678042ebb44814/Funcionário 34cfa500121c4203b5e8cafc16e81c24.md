# Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio de Aprovação (Tempo%20Me%CC%81dio%20de%20Aprovac%CC%A7a%CC%83o%20c8a5f4ff911040eab987f5a18cfdd9dc.md)

## Descrição

-