# Aplicativo Manifestação do Destinatário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Novas Notas (Novas%20Notas%20d7a437215ac84a10b37f07fcfac7cd56.md), Lançar na Compra (Lanc%CC%A7ar%20na%20Compra%20f68319680d1b487c8755e88a5f2ef329.md), Finalizadas (Finalizadas%200d0621efb4d146d3bcdf7fc562063ee1.md), Canceladas (Canceladas%20b1c548d5a1be43a7a388422e3b76663d.md), Fornecedor Não Cadastrado (Fornecedor%20Na%CC%83o%20Cadastrado%203ceb4b50f5d5491a9e835f462ec398b2.md)
Tarefa principal: Módulo Compra (Mo%CC%81dulo%20Compra%204f9b97b9ecc340d1989fe9c4e16de279.md)

## Descrição

-