# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total Desconto Venda (Total%20Desconto%20Venda%2028e9344cfb29470c943c868da68a269c.md)

## Descrição

-