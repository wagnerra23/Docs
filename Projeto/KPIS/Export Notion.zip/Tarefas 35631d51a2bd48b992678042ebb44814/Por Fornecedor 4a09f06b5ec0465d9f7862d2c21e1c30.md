# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Margem de Lucro  (Margem%20de%20Lucro%20147fe81c1e6340a28889829ff3398d40.md)

## Descrição

-