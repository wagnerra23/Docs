# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Riscos Identificados (Taxa%20de%20Riscos%20Identificados%20e8e10c58420b4506a12c31de74e2eda9.md)

## Descrição

-