# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Ticket Médio (Ticket%20Me%CC%81dio%20797c05028b934fde843fc416b73d8847.md)

## Descrição

-