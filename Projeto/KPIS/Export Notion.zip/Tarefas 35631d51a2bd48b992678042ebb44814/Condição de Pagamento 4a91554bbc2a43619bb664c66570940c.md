# Condição de Pagamento

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Recebimentos Parciais (Recebimentos%20Parciais%20521c99877af1459d87dd6f468578a56c.md)

## Descrição

-