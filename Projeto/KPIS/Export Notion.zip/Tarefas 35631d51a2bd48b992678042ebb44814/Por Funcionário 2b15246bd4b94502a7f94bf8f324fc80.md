# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total Acréscimo Venda (Total%20Acre%CC%81scimo%20Venda%201feeb245d23747efa3f2e57ac4430a01.md)

## Descrição

-