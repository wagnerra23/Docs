# Por Equipe

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Alteração da Equipe Padrão (Taxa%20de%20Alterac%CC%A7a%CC%83o%20da%20Equipe%20Padra%CC%83o%2052e9c82009d84e7e84e5dced3506e0b8.md)

## Descrição

-