# Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Rejeitadas (Rejeitadas%20fa9ebb427f144e55bbe647300276e198.md)

## Descrição

-