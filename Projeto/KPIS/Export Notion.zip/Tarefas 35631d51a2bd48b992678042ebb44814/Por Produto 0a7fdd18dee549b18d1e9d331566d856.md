# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio de Vida Útil Restante (Tempo%20Me%CC%81dio%20de%20Vida%20U%CC%81til%20Restante%2023d02b0d9a444200b888f891c1fcf23e.md)

## Descrição

-