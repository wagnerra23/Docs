# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Frete Mecânica (Total%20de%20Frete%20Meca%CC%82nica%20fbfa710331e04687b5daf256a0c559d8.md)

## Descrição

-