# Por Variação

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Perdas  (Total%20de%20Perdas%20cb19cd80748c429ab31b16c6280488de.md)

## Descrição

-