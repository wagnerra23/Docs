# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Médio de Crédito (Valor%20Me%CC%81dio%20de%20Cre%CC%81dito%2042a5c4499b6a4facb664deb43f21fe56.md)

## Descrição

-