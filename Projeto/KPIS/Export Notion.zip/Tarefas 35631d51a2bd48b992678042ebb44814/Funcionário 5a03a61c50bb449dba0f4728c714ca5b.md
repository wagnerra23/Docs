# Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Agendamento Cancelados (Agendamento%20Cancelados%20a05b15cf32154dfd96b169fae21704de.md)

## Descrição

-