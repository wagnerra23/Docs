# Aplicativo Múltiplos Estoques

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Taxa de Pedidos Atendidos (Taxa%20de%20Pedidos%20Atendidos%20717e683b9ec84102a9b78ddce60a775c.md), Taxa de Devoluções (Taxa%20de%20Devoluc%CC%A7o%CC%83es%200fe1fdbfe2f3436484c16d0ddb5023a4.md), Nível de Estoque Mínimo (Ni%CC%81vel%20de%20Estoque%20Mi%CC%81nimo%20959c436525c74956b8f7ff9b071f35dd.md), Nível de Estoque Máximo (Ni%CC%81vel%20de%20Estoque%20Ma%CC%81ximo%20476be4cc069e4b65b76ea5bf544c2988.md), Taxa de Ruptura de Estoque (Taxa%20de%20Ruptura%20de%20Estoque%20249263562f8647c4a64085a38a7de9cf.md), Custo de Transferência entre Locais (Custo%20de%20Transfere%CC%82ncia%20entre%20Locais%20f3c01ef50b5a4eb4b15dc789727f049a.md), Taxa de Utilização de Espaço de Armazenamento (Taxa%20de%20Utilizac%CC%A7a%CC%83o%20de%20Espac%CC%A7o%20de%20Armazenamento%20930eece4b1bc437c92effa8c9af1b0d5.md), Valor Total de Estoque  (Valor%20Total%20de%20Estoque%20beaf8a9b806e412ab73bf880c8472aa6.md), Taxa de Perdas (Taxa%20de%20Perdas%20382daae0f0e7445faed38c452a2f724f.md)
Tarefa principal: Módulo Estoque (Mo%CC%81dulo%20Estoque%2057c521e5356048fd955bdddfeedec937.md)
Tags: Despesa, Saldo

## Descrição

-