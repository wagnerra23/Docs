# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas com Acréscimo NFC-e (Taxa%20de%20Notas%20com%20Acre%CC%81scimo%20NFC-e%20b27d4735a3344da3965fb7c3e210c759.md)

## Descrição

-