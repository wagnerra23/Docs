# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Número de Serviços/Produtos Entregues (Nu%CC%81mero%20de%20Servic%CC%A7os%20Produtos%20Entregues%20dcc7697b42e4456b833f3b4506d6b1c9.md)

## Descrição

-