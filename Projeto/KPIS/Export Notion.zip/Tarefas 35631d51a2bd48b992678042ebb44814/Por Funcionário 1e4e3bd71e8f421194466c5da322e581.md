# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Não faturadas (Na%CC%83o%20faturadas%20071f3f5b2c9a4ca9900e10b028ff6109.md)

## Descrição

-