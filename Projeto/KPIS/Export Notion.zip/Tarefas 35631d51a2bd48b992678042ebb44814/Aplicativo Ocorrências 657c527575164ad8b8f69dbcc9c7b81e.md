# Aplicativo Ocorrências

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Taxa de Ocorrências com danos Totais (Taxa%20de%20Ocorre%CC%82ncias%20com%20danos%20Totais%20bc1203687c7e4113b56c1940e062ea72.md), Taxa de Ocorrências com danos Parciais (Taxa%20de%20Ocorre%CC%82ncias%20com%20danos%20Parciais%20529d6b54e47141048c60100067447a7f.md), Taxa de Ocorrências com Monta Pequena (Taxa%20de%20Ocorre%CC%82ncias%20com%20Monta%20Pequena%201b279b23f1e048c88ace3d531d50f9c8.md), Taxa de Ocorrências com Monta Média (Taxa%20de%20Ocorre%CC%82ncias%20com%20Monta%20Me%CC%81dia%204248875cf7a445758355c511be021dcb.md), Taxa de Ocorrências com Monta Grande (Taxa%20de%20Ocorre%CC%82ncias%20com%20Monta%20Grande%20d4d48a8c6ad44315a43887a35aa2f68e.md), Índice de Recorrência (I%CC%81ndice%20de%20Recorre%CC%82ncia%20bc65690f8811420f8a89773cea92dda0.md), Taxa de Ocorrências em Aberto (Taxa%20de%20Ocorre%CC%82ncias%20em%20Aberto%206a39614e47004abe9647b39369fd41ac.md), Taxa de Recuperação por Sistema Antifurto (Taxa%20de%20Recuperac%CC%A7a%CC%83o%20por%20Sistema%20Antifurto%2076453f9a67ab4e82b0d4f6cafb8e87c2.md), Média de Associados Participantes por Ocorrência (Me%CC%81dia%20de%20Associados%20Participantes%20por%20Ocorre%CC%82ncia%20fffa0b32a7ba40d6b6da55a099625670.md), Valor Total de Ocorrências (Valor%20Total%20de%20Ocorre%CC%82ncias%2050514946a8de4b598331fa13ccefbe79.md), Taxa de Ocorrências (Taxa%20de%20Ocorre%CC%82ncias%204c872d902cb34c42a88c70c9893b76f1.md)
Tarefa principal: Módulo Associação (Mo%CC%81dulo%20Associac%CC%A7a%CC%83o%207e02fd8f26b241c9b8b5f4fd5ab4988c.md)
Tags: Sinistro

## Descrição

-