# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio para Reabastecimento  (Tempo%20Me%CC%81dio%20para%20Reabastecimento%2015ab60c81f1247edb19d59f5999cfa39.md)

## Descrição

-