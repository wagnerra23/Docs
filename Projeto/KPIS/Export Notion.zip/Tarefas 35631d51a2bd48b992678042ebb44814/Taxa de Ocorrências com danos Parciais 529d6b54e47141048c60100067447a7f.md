# Taxa de Ocorrências com danos Parciais

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%205e5daf4e7acd4803aaa69f57577e7380.md), Por Placa (Por%20Placa%20e7b8890fbad241e09d8373103438a590.md)
Tarefa principal: Aplicativo Ocorrências (Aplicativo%20Ocorre%CC%82ncias%20657c527575164ad8b8f69dbcc9c7b81e.md)

## Descrição

-