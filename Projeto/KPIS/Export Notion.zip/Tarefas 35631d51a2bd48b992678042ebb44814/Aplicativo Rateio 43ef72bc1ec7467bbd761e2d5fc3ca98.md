# Aplicativo Rateio

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Retorno sobre Investimento (Retorno%20sobre%20Investimento%2021323dc146734d2f88d44afd07054ba3.md), Taxa de Precisão no Rateio (Taxa%20de%20Precisa%CC%83o%20no%20Rateio%20252e099c9cda4f4bbb54a71339f3c1da.md), Tempo Médio para Rateio (Tempo%20Me%CC%81dio%20para%20Rateio%20fb71e82aadf343b0bcf0701e6e019b8d.md), Taxa de Atraso no Rateio (Taxa%20de%20Atraso%20no%20Rateio%20e78d203857cd465aa420e9225ff7f1a7.md), Taxa de Sucesso em Auditorias (Taxa%20de%20Sucesso%20em%20Auditorias%2026f45a984f7f430ea4693f8eb651e946.md), Valor Médio por Rateio (Valor%20Me%CC%81dio%20por%20Rateio%20c6b0cea1d78049ac9e86a0912ab946a3.md), Média de Cotas por Rateio (Me%CC%81dia%20de%20Cotas%20por%20Rateio%2003143342b01845c2aa9dd42f6bfeac22.md), Valor Total de Rateios (Valor%20Total%20de%20Rateios%205078509b12564d699da67af1260090d0.md)
Tarefa principal: Módulo Associação (Mo%CC%81dulo%20Associac%CC%A7a%CC%83o%207e02fd8f26b241c9b8b5f4fd5ab4988c.md)
Tags: Receita

## Descrição

-