# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Produção (Taxa%20de%20Produc%CC%A7a%CC%83o%209356f3879318427aa597718b7fa1929d.md)

## Descrição

-