# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Vendas por Região (Vendas%20por%20Regia%CC%83o%20f42ace1a111c4d0eb084ce888c036288.md)

## Descrição

-