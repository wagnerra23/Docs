# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Transações Negadas (Transac%CC%A7o%CC%83es%20Negadas%20953f3c06319b40239a2ba29776eafa1b.md)

## Descrição

-