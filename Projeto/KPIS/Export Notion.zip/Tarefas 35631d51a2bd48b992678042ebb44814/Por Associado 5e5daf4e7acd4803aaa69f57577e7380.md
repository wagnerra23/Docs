# Por Associado

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Ocorrências com danos Parciais (Taxa%20de%20Ocorre%CC%82ncias%20com%20danos%20Parciais%20529d6b54e47141048c60100067447a7f.md)

## Descrição

-