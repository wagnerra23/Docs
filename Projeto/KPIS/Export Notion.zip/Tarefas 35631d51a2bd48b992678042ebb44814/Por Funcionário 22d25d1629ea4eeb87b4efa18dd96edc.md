# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas com Frete NF-e (Taxa%20de%20Notas%20com%20Frete%20NF-e%202251dc4000504a4f8ed5bc961b5438b7.md)

## Descrição

-