# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Lançamentos Manuais (Taxa%20de%20Lanc%CC%A7amentos%20Manuais%2034508b8f60774ceebd37147e12abfad0.md)

## Descrição

-