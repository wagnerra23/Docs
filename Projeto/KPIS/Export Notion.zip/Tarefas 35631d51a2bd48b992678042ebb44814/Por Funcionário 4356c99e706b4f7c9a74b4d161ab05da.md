# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Composições Sem Fórmula (Composic%CC%A7o%CC%83es%20Sem%20Fo%CC%81rmula%20ffc0fdd373e346728d71a830797dd323.md)

## Descrição

-