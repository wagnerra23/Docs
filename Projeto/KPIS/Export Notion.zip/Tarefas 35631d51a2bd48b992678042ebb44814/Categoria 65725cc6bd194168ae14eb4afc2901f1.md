# Categoria

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Margem de Lucro Markup (Margem%20de%20Lucro%20Markup%20a76a822247d344eba6b76625e069821d.md)

## Descrição

-