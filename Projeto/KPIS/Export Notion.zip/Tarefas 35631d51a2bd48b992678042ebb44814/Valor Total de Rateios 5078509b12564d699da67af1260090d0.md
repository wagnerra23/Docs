# Valor Total de Rateios

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%2039958e2ff9a346c185992519d8d70011.md), Por Placa (Por%20Placa%206c6dd44a2c27456d8eb95c0eb5d59c4b.md)
Tarefa principal: Aplicativo Rateio (Aplicativo%20Rateio%2043ef72bc1ec7467bbd761e2d5fc3ca98.md)

## Descrição

-