# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total Lucro (Total%20Lucro%200462d64e2a104f04866e519e0766fa30.md)

## Descrição

-