# Por Tipo de Nota

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Frete  (Total%20de%20Frete%20c5b90436f122484d97ea2f9dc4e45d46.md)

## Descrição

-