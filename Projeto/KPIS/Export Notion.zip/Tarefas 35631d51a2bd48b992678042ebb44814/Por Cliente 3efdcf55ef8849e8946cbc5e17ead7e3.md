# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Total de Recebimento Antecipado (Valor%20Total%20de%20Recebimento%20Antecipado%20755583d94cec461ea82c053bf993360d.md)

## Descrição

-