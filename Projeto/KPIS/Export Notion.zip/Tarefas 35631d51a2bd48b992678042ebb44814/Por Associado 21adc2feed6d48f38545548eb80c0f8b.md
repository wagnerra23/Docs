# Por Associado

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Retorno sobre Investimento (Retorno%20sobre%20Investimento%2021323dc146734d2f88d44afd07054ba3.md)

## Descrição

-