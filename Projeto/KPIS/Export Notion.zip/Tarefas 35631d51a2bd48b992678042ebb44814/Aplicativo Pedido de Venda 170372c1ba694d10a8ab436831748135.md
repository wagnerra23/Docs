# Aplicativo Pedido de Venda

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Volume de Pedidos (Volume%20de%20Pedidos%203b9c4820d926442784b109c42837b644.md), Total de Frete Pedido de Venda (Total%20de%20Frete%20Pedido%20de%20Venda%20c0030c83fcef468490c992f7af35c562.md), Total de Acréscimo Pedido de Venda (Total%20de%20Acre%CC%81scimo%20Pedido%20de%20Venda%20722076b72c1a4fe993c2789513e00b57.md), Tempo Médio de Processamento de Pedido (Tempo%20Me%CC%81dio%20de%20Processamento%20de%20Pedido%206af3f81968db4980a354ca5f041f8f6f.md), Pedidos Atrasados (Pedidos%20Atrasados%207c1355cb09ca4167996b492ffa4b793c.md), Ticket Médio  (Ticket%20Me%CC%81dio%2077e64bab388a4025aabc973bc7d11212.md), Inativas Pedido de Venda (Inativas%20Pedido%20de%20Venda%20083bf2529d61427fb245320818a2c9b1.md), Tempo Médio de Entrega (Tempo%20Me%CC%81dio%20de%20Entrega%207b05cfb1db824f08a71f5ae1555375a0.md), Pedidos Recorrentes (Pedidos%20Recorrentes%2080158ab788a14c6f8935f2e0fb000828.md), Pendentes de Envio a Produção (Pendentes%20de%20Envio%20a%20Produc%CC%A7a%CC%83o%20d6cc0d1a11b64d78a862d26d97a1234c.md), Abaixo do Valor Mínimo (Abaixo%20do%20Valor%20Mi%CC%81nimo%2032b2e6909d6d4a668d70b58ec9b5d576.md), Total de Pedidos (Total%20de%20Pedidos%2090b54dc7217a4cf2a67866247282b6e9.md)
Tarefa principal: Módulo Venda (Mo%CC%81dulo%20Venda%2019211818d4ab4c7eac5f69bcd9fe9f2e.md)
Tags: Acréscimo, Desconto, Frete

## Descrição

-