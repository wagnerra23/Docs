# Lançamentos Não Conciliados

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Cliente (Por%20Cliente%206e558f9178944559833eb939380b2621.md), Por Conta Bancária (Por%20Conta%20Banca%CC%81ria%20cb7abcb67293440bb4aba7e6b2dcd171.md)
Tarefa principal: Aplicativo Financeiro (Aplicativo%20Financeiro%20e0e69a8fedc04cb5b7abe3f6131009a0.md)
Descrição: Número de transações financeiras registradas que ainda não foram conciliadas com extratos bancários.

> **Prós:**
> 
> 
> **Precisão Contábil**: Este KPI ajuda a garantir a precisão das informações contábeis, identificando discrepâncias entre os registros internos e as transações bancárias.
> 
> **Detecção de Erros e Fraudes**: Auxilia na detecção precoce de erros de registro e possíveis fraudes.
> 
> **Melhoria dos Processos Financeiros**: Promove a revisão e melhoria contínua dos processos financeiros e de conciliação.
> 

> **Contras:**
> 
> 
> **Demanda de Tempo e Recursos**: A identificação e correção de lançamentos não conciliados podem ser processos demorados e consumir recursos significativos.
> 
> **Pode Indicar Problemas nos Processos**: Altos números de lançamentos não conciliados podem indicar falhas nos processos financeiros ou de controle interno.
> 
> **Estresse para a Equipe Financeira**: A necessidade constante de resolver discrepâncias pode sobrecarregar a equipe financeira.
> 

> **Módulo Responsável:**
Financeiro
> 

> **Função Principal:**
Monitorar o número de transações financeiras registradas pela empresa que ainda não foram conciliadas com os extratos bancários ou outras fontes externas de dados financeiros.
> 

> **Quais Configurações deve ter?**
> 
> 
> **Definição de Lançamento Não Conciliado**: Estabelecer critérios claros para o que constitui um lançamento não conciliado.
> 
> **Período de Análise**: Definir a frequência para revisão dos lançamentos (diária, semanal, mensal).
> 
> **Limiares de Alerta**: Configurar alertas para quando o número de lançamentos não conciliados exceder um limite pré-definido.
> 

> **Formato de Exibição?**
> 
> 
> **Número Total de Lançamentos Não Conciliados**: Apresentar a contagem como um número absoluto.
> 
> **Gráficos de Tendência**: Para visualizar a evolução do número de lançamentos não conciliados ao longo do tempo.
> 
> **Dashboards com Detalhes**: Mostrar os lançamentos não conciliados com informações detalhadas para facilitar a resolução.
> 

> **Possuí Relatórios? Quais?**
> 
> 
> **Relatório Detalhado de Lançamentos Não Conciliados**: Incluindo informações específicas para facilitar a investigação e correção.
> 
> **Análise de Tendências de Conciliação**: Observar padrões ou mudanças no volume de lançamentos não conciliados.
> 
> **Relatório de Resolução**: Acompanhar o progresso na resolução desses lançamentos.
> 

> **Requisitos para utilizar? E quais métricas se associam a esse KPI?**
> 
> 
> Sistema de gestão financeira que permite rastrear e conciliar transações.
> 
> Processos claros para a conciliação de contas.
> 
> **Métricas Associadas:**
> 
> - **Tempo Médio para Conciliação**: Quanto tempo leva, em média, para conciliar um lançamento.
> - **Categorias de Lançamentos Não Conciliados**: Tipos de transações mais propensas a discrepâncias.
> - **Impacto Financeiro**: Avaliação do impacto financeiro dos lançamentos não conciliados.