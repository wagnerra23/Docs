# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Pedidos (Total%20de%20Pedidos%2090b54dc7217a4cf2a67866247282b6e9.md)

## Descrição

-