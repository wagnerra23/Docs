# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Transações (Total%20de%20Transac%CC%A7o%CC%83es%20228eb7c20dd64d6fba615531e6e14b6d.md)

## Descrição

-