# Valor Total de Boletos Pagos Boletos Associados

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%2059a456f848f9479599a46a65bc08d583.md), Por Placa (Por%20Placa%20cd379d983e76487fa57efe51035ee3f0.md)
Tarefa principal: Aplicativo Boletos Eventuais (Aplicativo%20Boletos%20Eventuais%20a83496ea73e94c07b9366202de2555da.md)

## Descrição

-