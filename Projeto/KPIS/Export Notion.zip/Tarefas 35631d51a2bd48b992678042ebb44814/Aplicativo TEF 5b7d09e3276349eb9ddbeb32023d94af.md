# Aplicativo TEF

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Tempo Médio de Processamento TEF (Tempo%20Me%CC%81dio%20de%20Processamento%20TEF%203cedf5ee9ac54eb993d68bade9fe0d21.md), Falhas de Transações (Falhas%20de%20Transac%CC%A7o%CC%83es%20e0a1b15e2cc64178939e15d69644f2ae.md), Volume de Transações TEF (Volume%20de%20Transac%CC%A7o%CC%83es%20TEF%20fe0d5944e38f4459a0d2fd926c386773.md), Valor Médio de Transação (Valor%20Me%CC%81dio%20de%20Transac%CC%A7a%CC%83o%20999b7493bcca4e8f82aeb85fcd09093f.md), Valor de Estornos (Valor%20de%20Estornos%2038d5f589453e47b9b02dcd8951e9557a.md), Disponibilidade do Sistema (Disponibilidade%20do%20Sistema%20431171cb359f43b0a83affbe6933cf11.md), Transações Parceladas (Transac%CC%A7o%CC%83es%20Parceladas%2034a16f5132824ed993d52950144f0ceb.md), Total de Transações (Total%20de%20Transac%CC%A7o%CC%83es%20228eb7c20dd64d6fba615531e6e14b6d.md), Transações Negadas (Transac%CC%A7o%CC%83es%20Negadas%20953f3c06319b40239a2ba29776eafa1b.md)
Tarefa principal: Módulo Venda (Mo%CC%81dulo%20Venda%2019211818d4ab4c7eac5f69bcd9fe9f2e.md)

## Descrição

-