# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Inativas PDV (Inativas%20PDV%209b54b97e27d54e84b4fd2bca45a9922f.md)

## Descrição

-