# Por Setor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Pagamentos Pontuais (Taxa%20de%20Pagamentos%20Pontuais%204b8e347468d048b08d948f86519c2e4d.md)

## Descrição

-