# Taxa de Precisão no Rateio

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%20436f7e1d5249471995741f3dcfac7c37.md), Por Placa (Por%20Placa%2023074d9ab16a49d09ce3740d72521a45.md)
Tarefa principal: Aplicativo Rateio (Aplicativo%20Rateio%2043ef72bc1ec7467bbd761e2d5fc3ca98.md)

## Descrição

-