# Aplicativo Fabricação (Composição)

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Diferença de Valor (Diferenc%CC%A7a%20de%20Valor%20dbadb02bb3da40448d85abb33d338b02.md), Composições Sem Fórmula (Composic%CC%A7o%CC%83es%20Sem%20Fo%CC%81rmula%20ffc0fdd373e346728d71a830797dd323.md), Taxa de Utilização de Máteria-Prima (Taxa%20de%20Utilizac%CC%A7a%CC%83o%20de%20Ma%CC%81teria-Prima%20ff6f31be69584db28e0a66d671e54a87.md), Taxa de Rendimento (Taxa%20de%20Rendimento%207f60c503f72b4afc8908b5440fcd7409.md), Margem de Lucro Fabricação (Margem%20de%20Lucro%20Fabricac%CC%A7a%CC%83o%20833455d145894dc183ac9bf6ad56babe.md), Retorna Estoque (Retorna%20Estoque%208749a720a8dc419698aea1575ff1f579.md)
Tarefa principal: Módulo Produção (Mo%CC%81dulo%20Produc%CC%A7a%CC%83o%209c742a8e253f45c0baa028ea30ec8d74.md)
Tags: Acréscimo, Desconto, Rendimento

## Descrição

-