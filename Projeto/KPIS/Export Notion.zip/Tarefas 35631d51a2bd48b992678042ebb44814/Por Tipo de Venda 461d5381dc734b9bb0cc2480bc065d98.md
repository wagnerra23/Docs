# Por Tipo de Venda

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Vendas Venda (Total%20de%20Vendas%20Venda%20b4f11d3253b44e29bd71bbb1e769e99b.md)

## Descrição

-