# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Pré-Requisitos (Taxa%20de%20Pre%CC%81-Requisitos%20f1e46a48810e42e095d36c5b7d44fd3c.md)

## Descrição

-