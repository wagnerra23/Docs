# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Finalizadas Sem Conferência (Finalizadas%20Sem%20Confere%CC%82ncia%20c418f3370a214d7aa391bd24f4851b82.md)

## Descrição

-