# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Atualizações de Estoque (Taxa%20de%20Atualizac%CC%A7o%CC%83es%20de%20Estoque%20b1f528ca005448eab81502bfc46fa081.md)

## Descrição

-