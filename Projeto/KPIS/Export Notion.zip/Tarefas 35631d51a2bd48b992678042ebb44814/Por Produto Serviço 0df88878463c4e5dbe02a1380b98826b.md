# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Média de Lucro Tabela de Preço (Me%CC%81dia%20de%20Lucro%20Tabela%20de%20Prec%CC%A7o%20cfa4873428964f49b47cb5603d60c0f6.md)

## Descrição

-