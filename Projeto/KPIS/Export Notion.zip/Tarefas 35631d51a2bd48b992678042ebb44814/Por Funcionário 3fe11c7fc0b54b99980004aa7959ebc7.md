# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Acréscimo (Total%20de%20Acre%CC%81scimo%2039187d5310f140619850afbab165661c.md)

## Descrição

-