# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo de Reposição (Tempo%20de%20Reposic%CC%A7a%CC%83o%20438aaf1474ce48d5af6ef9af0a063c72.md)

## Descrição

-