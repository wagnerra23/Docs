# Por Associado

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Ocorrências em Aberto (Taxa%20de%20Ocorre%CC%82ncias%20em%20Aberto%206a39614e47004abe9647b39369fd41ac.md)

## Descrição

-