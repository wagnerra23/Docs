# Por Placa

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio para Rateio (Tempo%20Me%CC%81dio%20para%20Rateio%20fb71e82aadf343b0bcf0701e6e019b8d.md)

## Descrição

-