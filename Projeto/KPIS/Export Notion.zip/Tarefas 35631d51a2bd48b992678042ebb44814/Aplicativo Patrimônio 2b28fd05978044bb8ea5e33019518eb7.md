# Aplicativo Patrimônio

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Taxa de Depreciação de Ativos (Taxa%20de%20Depreciac%CC%A7a%CC%83o%20de%20Ativos%201616783824c54e31a060c62930f72992.md), Custo Total de Ativos (Custo%20Total%20de%20Ativos%202d7dc350bb464937a928d4a6477774b0.md), Valor de Retorno sobre Ativos (Valor%20de%20Retorno%20sobre%20Ativos%20b7cb5c0acba140bbb02fb1f8a928c158.md), Tempo Médio entre Falhas (Tempo%20Me%CC%81dio%20entre%20Falhas%20eb45e49247594d98baf192ffcc6491e6.md), Tempo Médio para Reparo (Tempo%20Me%CC%81dio%20para%20Reparo%20a949dd78c2f1401cabdaee34c26da532.md), Taxa de Utilização de Ativos (Taxa%20de%20Utilizac%CC%A7a%CC%83o%20de%20Ativos%202532145a42fa4480882b43e1bb0ff518.md), Custo de Manutenção (Custo%20de%20Manutenc%CC%A7a%CC%83o%20e9ed020ff52d454aa49af1ed5ddb23a5.md), Tempo Médio de Venda de Ativos (Tempo%20Me%CC%81dio%20de%20Venda%20de%20Ativos%2092311e40a1914210a0ecea7d3f34278f.md), Valor Residual de Ativos (Valor%20Residual%20de%20Ativos%2099fbdc99ae13418b9e25f08cd1850ec3.md), Custo Operacional de Ativos (Custo%20Operacional%20de%20Ativos%20e48e218da0254d549a250ca23d3472a6.md), Eficiência Energética de Ativos (Eficie%CC%82ncia%20Energe%CC%81tica%20de%20Ativos%20743bf73d3cc54176bd2113a577b5933a.md)
Tarefa principal: Módulo Estoque (Mo%CC%81dulo%20Estoque%2057c521e5356048fd955bdddfeedec937.md)
Tags: Depreciação, Saldo

## Descrição

-