# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Número de Transações (Nu%CC%81mero%20de%20Transac%CC%A7o%CC%83es%2000731754cc534fab8f1af797a76feea1.md)

## Descrição

-