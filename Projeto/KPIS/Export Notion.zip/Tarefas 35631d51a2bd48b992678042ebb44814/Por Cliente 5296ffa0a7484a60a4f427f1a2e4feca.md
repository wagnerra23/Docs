# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Enviados Para Protesto (Enviados%20Para%20Protesto%20cbb115448cc44f2c908e0a8376a11637.md)

## Descrição

-