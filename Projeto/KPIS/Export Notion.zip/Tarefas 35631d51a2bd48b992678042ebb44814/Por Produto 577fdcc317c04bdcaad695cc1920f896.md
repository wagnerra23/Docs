# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Total de Desconto  (Valor%20Total%20de%20Desconto%20d38fdf11d7d04700884d4dcf31a1460b.md)

## Descrição

-