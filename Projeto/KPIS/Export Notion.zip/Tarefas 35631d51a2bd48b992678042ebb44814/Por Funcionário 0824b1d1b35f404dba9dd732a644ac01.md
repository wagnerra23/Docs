# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas com Desconto NFC-e (Taxa%20de%20Notas%20com%20Desconto%20NFC-e%204f74251644b34ca59b22611180c79c84.md)

## Descrição

-