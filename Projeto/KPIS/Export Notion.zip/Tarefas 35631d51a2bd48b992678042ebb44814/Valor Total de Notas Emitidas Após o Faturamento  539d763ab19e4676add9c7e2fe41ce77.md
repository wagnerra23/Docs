# Valor Total de Notas Emitidas Após o Faturamento (Pendente)

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Aplicativo NF-e (Aplicativo%20NF-e%206408f7e696e44074a7f68d6002bc3c72.md)
Tags: BI

## Descrição

-