# Por Placa

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Médio por Rateio (Valor%20Me%CC%81dio%20por%20Rateio%20c6b0cea1d78049ac9e86a0912ab946a3.md)

## Descrição

-