# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Desconto PDV (Total%20de%20Desconto%20PDV%202bd3909a8ec04f379a44616570e03244.md)

## Descrição

-