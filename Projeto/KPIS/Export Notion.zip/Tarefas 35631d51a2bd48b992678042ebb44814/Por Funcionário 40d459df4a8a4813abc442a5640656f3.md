# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Notas Emitidas Após Faturamento NF-e (Taxa%20de%20Notas%20Emitidas%20Apo%CC%81s%20Faturamento%20NF-e%20eb2c67347d4b44eeb720ab7c5bed4c91.md)

## Descrição

-