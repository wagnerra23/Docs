# Por Fornecedor

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Estoque Máximo (Estoque%20Ma%CC%81ximo%20db0b95b7832845e7ac37834b0d85f6f1.md)

## Descrição

-