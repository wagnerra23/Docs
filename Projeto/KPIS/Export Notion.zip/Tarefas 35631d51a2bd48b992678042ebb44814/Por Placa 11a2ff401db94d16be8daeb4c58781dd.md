# Por Placa

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Variação da Taxa de Emissão no Período (Variac%CC%A7a%CC%83o%20da%20Taxa%20de%20Emissa%CC%83o%20no%20Peri%CC%81odo%20f88643c3a47342af840892cd3d2721af.md)

## Descrição

-