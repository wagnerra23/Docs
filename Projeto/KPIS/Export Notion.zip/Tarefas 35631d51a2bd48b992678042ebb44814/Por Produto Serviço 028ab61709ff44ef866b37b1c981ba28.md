# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Acréscimo Pedido de Venda (Total%20de%20Acre%CC%81scimo%20Pedido%20de%20Venda%20722076b72c1a4fe993c2789513e00b57.md)

## Descrição

-