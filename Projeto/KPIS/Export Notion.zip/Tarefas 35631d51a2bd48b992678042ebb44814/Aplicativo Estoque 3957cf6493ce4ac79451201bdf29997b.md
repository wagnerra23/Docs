# Aplicativo Estoque

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Custo de Carregamento de Estoque (Custo%20de%20Carregamento%20de%20Estoque%20b363557b44094444a3a8d42eb729faca.md), Valor Total do Estoque - Estoque (Valor%20Total%20do%20Estoque%20-%20Estoque%20f41abe2f24e84d4fb63bbff60015d583.md), Nível de Serviço de Estoque (Ni%CC%81vel%20de%20Servic%CC%A7o%20de%20Estoque%202708e016321547d7968302ee5b5a526b.md), Taxa de Falta de Estoque (Taxa%20de%20Falta%20de%20Estoque%206f277110fde54fbbb43fadbe9faa90c1.md), Tempo de Reposição (Tempo%20de%20Reposic%CC%A7a%CC%83o%20438aaf1474ce48d5af6ef9af0a063c72.md), Taxa de Produtos Acima do Estoque Máximo (Taxa%20de%20Produtos%20Acima%20do%20Estoque%20Ma%CC%81ximo%20d00c6443f89e4156a40a17714688924b.md), Taxa de Produtos Abaixo do Estoque Mínimo (Taxa%20de%20Produtos%20Abaixo%20do%20Estoque%20Mi%CC%81nimo%20daa10f8046c5453eb8821a8d832e0304.md), Valor Total  de Perdas (Valor%20Total%20de%20Perdas%2015f245125a714aeba2043d15f46aa2ad.md), Valor Total Excedente de Estoque (Valor%20Total%20Excedente%20de%20Estoque%20fafb882071cb4f0a976df1e0fc5f0ecf.md), Volume Total de Estoque (Volume%20Total%20de%20Estoque%20f14f1dd54fd849269ba6c2def4f2e234.md)
Tarefa principal: Módulo Estoque (Mo%CC%81dulo%20Estoque%2057c521e5356048fd955bdddfeedec937.md)
Tags: Acúmulo, Perda, Saldo, Sem Rotatividade

## Descrição

-