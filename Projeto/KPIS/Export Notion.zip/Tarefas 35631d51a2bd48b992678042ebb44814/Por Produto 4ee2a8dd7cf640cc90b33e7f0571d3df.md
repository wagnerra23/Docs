# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Pedidos Atendidos (Taxa%20de%20Pedidos%20Atendidos%20717e683b9ec84102a9b78ddce60a775c.md)

## Descrição

-