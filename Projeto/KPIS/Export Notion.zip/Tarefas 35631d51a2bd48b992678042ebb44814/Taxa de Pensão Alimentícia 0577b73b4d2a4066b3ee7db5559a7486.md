# Taxa de Pensão Alimentícia

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Setor (Por%20Setor%20d6e8c2b92dcf4c1783d4bb31b329465c.md), Por Funcionário (Por%20Funciona%CC%81rio%20b21531d0acc342fd9c689d154672467d.md)
Tarefa principal: Aplicativo Funcionários (Aplicativo%20Funciona%CC%81rios%20ce8540fd90b64211ad96c8b7224afc7e.md)
Descrição: Monitora a porcentagem  dos descontos em folha de pagamento destinados ao pagamento de pensão alimentícia por parte dos colaboradores que têm essa obrigação legal.

> **Prós:**
> 
> 
> Assegura que a empresa esteja cumprindo com as determinações legais e judiciais.
> 
> Mantém um controle efetivo sobre os descontos aplicados na folha de pagamento, evitando erros administrativos.
> 
> Pode refletir a responsabilidade social da empresa e sua atenção para com a situação familiar dos funcionários.
> 

> **Contras:**
> 
> 
> A presença de altos valores ou uma grande proporção de funcionários com pensão alimentícia pode indicar questões sociais amplas que afetam a força de trabalho.
> 
> A gestão e o rastreamento dessas informações devem ser tratados com confidencialidade, o que pode ser desafiador.
> 
> O KPI por si só não oferece soluções para possíveis problemas subjacentes que podem estar levando a altas taxas de obrigações de pensão alimentícia.
> 

> **Módulo Responsável:**
RH
> 

> **Função Principal:**
Garantir que os processos de desconto e repasse de pensão alimentícia estão sendo geridos corretamente e em conformidade com as leis e decisões judiciais aplicáveis.
> 

> **Quais Configurações deve ter?**
> 
> 
> Identificação dos funcionários com obrigações de pensão alimentícia.
> 
> Cálculo do valor total descontado e repassado.
> 
> Segregação dos dados para manter a privacidade dos funcionários envolvidos.
> 

> **Formato de Exibição?**
> 
> 
> Valor total ou percentual de descontos realizados na folha de pagamento.
> 
> Gráficos de barras ou linhas que representem a tendência desses valores ao longo do tempo.
> 

> **Possuí Relatórios? Quais?**
> 
> 
> Relatórios detalhados que documentem os descontos realizados por pensão alimentícia, mantendo a confidencialidade dos dados pessoais dos funcionários.
> 
> Auditorias periódicas para assegurar a precisão dos valores descontados e repassados.
> 

> **Requisitos para utilizar? E quais métricas se associam a esse KPI?**
> 
> 
> Sistema de folha de pagamento que possa gerenciar descontos legais específicos como a pensão alimentícia.
> 
> Processos claros de verificação e cumprimento das ordens judiciais relacionadas à pensão alimentícia.
> 
> **Métricas Associadas:**
> 
> - Número de funcionários com obrigações de pensão alimentícia.
> - Regularidade dos pagamentos realizados pela empresa.
> - Incidência de erros ou atrasos nos repasses dos valores de pensão.