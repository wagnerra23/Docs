# Módulo Estoque

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Aplicativo Patrimônio (Aplicativo%20Patrimo%CC%82nio%202b28fd05978044bb8ea5e33019518eb7.md), Aplicativo Múltiplos Estoques (Aplicativo%20Mu%CC%81ltiplos%20Estoques%204eb66a5c0ebd4fb0ab9129c3b0adb331.md), Aplicativo Lote (Aplicativo%20Lote%203982e5db473449e4a24a219ebf716f73.md), Aplicativo Grade (Aplicativo%20Grade%20dc9b59636795467db5c7d4db5cfdc44b.md), Aplicativo Estoque (Aplicativo%20Estoque%203957cf6493ce4ac79451201bdf29997b.md), Aplicativo Balanço de Estoque (Aplicativo%20Balanc%CC%A7o%20de%20Estoque%208c57889820d242d2881af8d1dfc28276.md), Aplicativo Código de Barras (Aplicativo%20Co%CC%81digo%20de%20Barras%20a801a9bbe475456685c2bff0986f84e5.md)
Tarefa principal: EMPRESA (EMPRESA%201a28ba15cf0742499f888af9f25353c5.md)
Tags: = Saldo Atual, Despesa, Receita

## Descrição

-