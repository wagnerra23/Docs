# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Devoluções (Taxa%20de%20Devoluc%CC%A7o%CC%83es%200fe1fdbfe2f3436484c16d0ddb5023a4.md)

## Descrição

-