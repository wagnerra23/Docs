# Aplicativo Notificações

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Módulo Produtividade (?) (Mo%CC%81dulo%20Produtividade%20(%20)%203292b5bea8694c9bb1f317ff6e29cb2f.md)

## Descrição

-