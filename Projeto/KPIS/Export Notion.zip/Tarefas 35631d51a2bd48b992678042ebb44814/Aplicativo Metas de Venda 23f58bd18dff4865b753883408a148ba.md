# Aplicativo Metas de Venda

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Tempo Médio para Alcance da Meta (Tempo%20Me%CC%81dio%20para%20Alcance%20da%20Meta%20a16b83aa37a84d75af8613e4e4508db0.md), Ajuste de Metas (Ajuste%20de%20Metas%2043f398bbe7bc439490d2856327939387.md), Custo por Meta Alcançada (Custo%20por%20Meta%20Alcanc%CC%A7ada%20dcdb89c0a2594301888907a8898ed4c7.md)
Tarefa principal: Módulo Venda (Mo%CC%81dulo%20Venda%2019211818d4ab4c7eac5f69bcd9fe9f2e.md)

## Descrição

-