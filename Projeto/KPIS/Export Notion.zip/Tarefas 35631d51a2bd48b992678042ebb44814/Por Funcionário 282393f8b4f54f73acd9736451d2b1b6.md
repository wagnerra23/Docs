# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio de Atendimento (Tempo%20Me%CC%81dio%20de%20Atendimento%20644c3c75e46b42f3b6aef6834ebd1e1d.md)

## Descrição

-