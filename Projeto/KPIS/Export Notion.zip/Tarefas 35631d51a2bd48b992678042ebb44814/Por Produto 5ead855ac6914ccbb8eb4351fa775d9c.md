# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Inativas Pedido de Venda (Inativas%20Pedido%20de%20Venda%20083bf2529d61427fb245320818a2c9b1.md)

## Descrição

-