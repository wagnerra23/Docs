# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Retorno sobre Investimento de Comissão (Retorno%20sobre%20Investimento%20de%20Comissa%CC%83o%20d9c63ee940e8451db1099853587fdb4b.md)

## Descrição

-