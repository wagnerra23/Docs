# Módulo Compra

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Aplicativo Solicitação de Compra (Aplicativo%20Solicitac%CC%A7a%CC%83o%20de%20Compra%20915d1edb3b2e4157865893ee0f7a3296.md), Aplicativo SubUnidade (Aplicativo%20SubUnidade%206d66de5f684a498c94d2287a2250ff14.md), Aplicativo Compra (Aplicativo%20Compra%20f785a10f5fb54534a75ed06aa1698b93.md), Aplicativo Manifestação do Destinatário (Aplicativo%20Manifestac%CC%A7a%CC%83o%20do%20Destinata%CC%81rio%205b4d0fc758eb4caab5eab804a60bdcc7.md)
Tarefa principal: EMPRESA (EMPRESA%201a28ba15cf0742499f888af9f25353c5.md)
Tags: = Saldo Atual, Despesa, Receita

## Descrição

-