# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Problemas/Incidentes (Taxa%20de%20Problemas%20Incidentes%203baebb114bc640c88283abb39d0f94fb.md)

## Descrição

-