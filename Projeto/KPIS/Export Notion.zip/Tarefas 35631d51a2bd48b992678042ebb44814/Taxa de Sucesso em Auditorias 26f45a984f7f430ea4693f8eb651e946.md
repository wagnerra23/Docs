# Taxa de Sucesso em Auditorias

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Aplicativo Rateio (Aplicativo%20Rateio%2043ef72bc1ec7467bbd761e2d5fc3ca98.md)

## Descrição

-