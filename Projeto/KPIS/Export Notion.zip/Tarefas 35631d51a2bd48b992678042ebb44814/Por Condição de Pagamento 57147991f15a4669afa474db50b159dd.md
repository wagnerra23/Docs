# Por Condição de Pagamento

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor de Desconto Obtido (Valor%20de%20Desconto%20Obtido%20c36f568e964440bb8b937cc6f3256dd1.md)

## Descrição

-