# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio de Entrega (Tempo%20Me%CC%81dio%20de%20Entrega%207b05cfb1db824f08a71f5ae1555375a0.md)

## Descrição

-