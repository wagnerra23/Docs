# Por Cliente

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Pendentes de Impressão (Pendentes%20de%20Impressa%CC%83o%205449a0900abb4837be4a17ed25f19cb5.md)

## Descrição

-