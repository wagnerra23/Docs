# Enviados para Protesto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%20ae7067ff68e3452bb65b0a442ba5ca46.md)
Tarefa principal: Aplicativo Boletos Eventuais (Aplicativo%20Boletos%20Eventuais%20a83496ea73e94c07b9366202de2555da.md)

## Descrição

-