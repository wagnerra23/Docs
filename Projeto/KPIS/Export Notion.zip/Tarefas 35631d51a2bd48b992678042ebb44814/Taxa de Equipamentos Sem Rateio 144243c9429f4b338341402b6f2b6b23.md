# Taxa de Equipamentos Sem Rateio

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Agrupando Por :: Por Associado (Por%20Associado%2019e2c11c5f704130a2fb7d5c84c07b81.md)
Tarefa principal: Aplicativo Equipamentos (Aplicativo%20Equipamentos%2031b53b0b92894bada4c0cf0eb973d9e3.md)

## Descrição

-