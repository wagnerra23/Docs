# Por Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Valor Total  de Perdas (Valor%20Total%20de%20Perdas%2015f245125a714aeba2043d15f46aa2ad.md)

## Descrição

-