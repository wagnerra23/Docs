# Por Produto/Serviço

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Vínculos Realizados (Vi%CC%81nculos%20Realizados%2015962aed4fb0477c908a1d17476b7dfb.md)

## Descrição

-