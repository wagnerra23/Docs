# Por Associado

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Taxa de Ocorrências com Monta Média (Taxa%20de%20Ocorre%CC%82ncias%20com%20Monta%20Me%CC%81dia%204248875cf7a445758355c511be021dcb.md)

## Descrição

-