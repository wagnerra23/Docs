# Por Grupo de Produto

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Total de Vendas PAF (Total%20de%20Vendas%20PAF%20da151f758ba64a3b82bf9cc09399bc6a.md)

## Descrição

-