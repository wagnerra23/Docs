# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Sangrias do Período (Sangrias%20do%20Peri%CC%81odo%20b265b8c647be4687bc361e2543e5f945.md)

## Descrição

-