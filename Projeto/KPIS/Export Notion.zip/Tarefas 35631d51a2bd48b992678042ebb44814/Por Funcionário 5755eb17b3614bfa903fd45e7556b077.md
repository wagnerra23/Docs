# Por Funcionário

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Abaixo do Valor Mínimo (Abaixo%20do%20Valor%20Mi%CC%81nimo%2032b2e6909d6d4a668d70b58ec9b5d576.md)

## Descrição

-