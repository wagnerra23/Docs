# Por Condição de Pagamento

Status: Não iniciado
Projeto: KPI’s (../KPI%E2%80%99s%20d82325c7c49b48189ca757318627d788.md)
Tarefa principal: Tempo Médio de Processamento TEF (Tempo%20Me%CC%81dio%20de%20Processamento%20TEF%203cedf5ee9ac54eb993d68bade9fe0d21.md)

## Descrição

-